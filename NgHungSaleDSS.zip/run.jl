using Pkg
Pkg.activate(@__DIR__)
using SaleDSS
SaleDSS.main()
