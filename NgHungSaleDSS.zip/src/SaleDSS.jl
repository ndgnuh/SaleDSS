module SaleDSS

using Dates
using Dash
using DashHtmlComponents
using DashCoreComponents
using DashBootstrapComponents
using DashTable
using CSV, DataFrames

app = dash(; external_stylesheets=[dbc_themes.FLATLY])

const brand = "SaleDSS"
const nav = dbc_navbarsimple(; brand=brand, color="primary", dark=true, fluid=true) do
    dbc_navlink("Home"; href="/"),
    dbc_navlink("Report"; href="/report"),
    dbc_navlink("Prediction"; href="/predict"),
    dbc_navlink("ML Analysis"; href="/analysis"),
    dbc_dropdownmenu(; nav=true, in_navbar=true, label="User A") do
        dbc_dropdownmenuitem("Profile"),
        dbc_dropdownmenuitem("Settings"),
        dbc_dropdownmenuitem("Logout")
    end
end

app.layout = html_div() do
    data = CSV.read("data/supermaket_sales.csv", DataFrame)
    nav,
    dbc_container(; fluid=true) do
        dbc_row() do
            dbc_col() do
                cogs = data[!, :cogs]
                times = data[!, :Time]
                dcc_graph(;
                    id="example-graph",
                    figure=(
                        data=[(x=times, y=cogs, type="line", name="SF")],
                        layout=(title="Dash Data Visualization",),
                    ),
                )
            end,
            # PIE CHART ON GENDERS
            dbc_col() do
                genders = data[!, :Gender]
                labels = unique(genders)
                values = map(labels) do label
                    count(isequal(label), genders)
                end
                dcc_graph(;
                    id="gender-pie",
                    figure=(
                        data=[(
                            values=values,
                            labels=labels,
                            type="pie",
                            name="Customer by gender",
                        )],
                        layout=(title="Customer by gender",),
                    ),
                )
            end
        end
    end
end

function main()
    host = get(ENV, "HOST", "0.0.0.0")
    port = get(ENV, "PORT", "8080")
    return run_server(app, "0.0.0.0", 8080; debug=true)
end

function julia_main()::Cint
    try
        # @show ARGS
        # @show Base.PROGRAM_FILE
        # @show DEPOT_PATH
        # @show LOAD_PATH
        # @show pwd()
        # @show Base.active_project()
        # @show Threads.nthreads()
        # @show Sys.BINDIR
        # display(Base.loaded_modules)
        main()
        println()
    catch
        Base.invokelatest(Base.display_error, Base.catch_stack())
    end
    return 0
end

end # module
